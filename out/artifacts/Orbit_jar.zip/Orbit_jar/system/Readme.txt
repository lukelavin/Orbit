This directory contains FXGL system data files.

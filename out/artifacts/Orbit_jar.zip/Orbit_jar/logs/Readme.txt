This directory contains FXGL log files.
